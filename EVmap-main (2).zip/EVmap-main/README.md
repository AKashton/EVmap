# EVmap
Developing a online map to display charging station allocation model.
currently a work in progress
